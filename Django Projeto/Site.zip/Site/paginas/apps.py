from django.apps import AppConfig


class PaginasConfig(AppConfig):
    name = 'paginas'
